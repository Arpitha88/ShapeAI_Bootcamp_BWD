import React from "react";

function Header() {
  return (
    <header>
      <h1>Arpitha Kiddoo.com</h1>
    </header>
  );
}

export default Header;
