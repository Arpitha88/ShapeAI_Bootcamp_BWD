import React from "react";

function Info() {
  return (
    <div className="note">
      <h1>JavaScript and React.js BootCamp</h1>
      <p>A Basic web dev React Js By SJP Ec BootCamp</p>
    </div>
  );
}

export default Info;
